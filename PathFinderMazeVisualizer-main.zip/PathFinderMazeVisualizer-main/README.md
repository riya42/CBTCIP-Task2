# PathFinderMazeVisualizer
A*, Dijkstra, maze generation etc. visualizers using only javascript


A javascript visualizer with fucntionality to visualize different PathFinding algos.

Funcitonalitites:
  * Algorithms visualised:
     1. A*
     2. Dijkstra
     3. Bfs
     4. Dfs
  * can generate maze randomly also
  * can remove and add wall by interest from anywhere
  * can change location of starting and ending point

## keep studyin 😴!
